import os, sqlite3, threading, time, uuid, shutil, mimetypes
from pathlib import Path
from urllib.parse import quote

import requests
from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

DATA = Path(os.getenv('DATA_DIR', '/data'))
REELS = DATA / 'reels'
UPLOADED = DATA / 'uploaded'
LOGS = DATA / 'logs'
DB_PATH = DATA / 'queue.db'
for p in (REELS, UPLOADED, LOGS): p.mkdir(parents=True, exist_ok=True)

IG_USER_ID = os.getenv('INSTAGRAM_USER_ID', '').strip()
ACCESS_TOKEN = os.getenv('INSTAGRAM_ACCESS_TOKEN', '').strip()
API_BASE = os.getenv('INSTAGRAM_API_BASE', 'https://graph.instagram.com').rstrip('/')
API_VERSION = os.getenv('INSTAGRAM_API_VERSION', 'v25.0').strip()
DASHBOARD_KEY = os.getenv('DASHBOARD_KEY', '').strip()
SHARE_TO_FEED = os.getenv('SHARE_TO_FEED', 'true').lower() == 'true'
POLL_INTERVAL = int(os.getenv('POLL_INTERVAL', '10'))
POLL_TIMEOUT = int(os.getenv('POLL_TIMEOUT', '900'))

app = FastAPI(title='Auto Reels Cloud')
app.mount('/static', StaticFiles(directory='/mnt/data/auto-reels-cloud/static'), name='static')
templates = Jinja2Templates(directory='/mnt/data/auto-reels-cloud/templates')

DB_LOCK = threading.Lock()

def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            original_name TEXT NOT NULL,
            public_key TEXT UNIQUE NOT NULL,
            caption TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'pending',
            message TEXT NOT NULL DEFAULT '',
            media_id TEXT DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )''')
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('hashtags','')")

def get_setting(key):
    with db() as c:
        row = c.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        return row['value'] if row else ''

def set_setting(key, value):
    with db() as c:
        c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, value))

def auth_ok(request: Request):
    if not DASHBOARD_KEY:
        return True
    return request.query_params.get('key') == DASHBOARD_KEY or request.headers.get('X-Dashboard-Key') == DASHBOARD_KEY

def check_auth(request: Request):
    if not auth_ok(request):
        raise HTTPException(401, 'Acesso não autorizado. Use ?key=SEU_DASHBOARD_KEY.')

def api_request(method, path, params=None):
    if not IG_USER_ID or not ACCESS_TOKEN:
        raise RuntimeError('INSTAGRAM_USER_ID e INSTAGRAM_ACCESS_TOKEN precisam estar configurados no Railway.')
    url = f'{API_BASE}/{API_VERSION}/{path.lstrip("/")}'
    params = dict(params or {})
    params['access_token'] = ACCESS_TOKEN
    r = requests.request(method, url, params=params, timeout=60)
    try: data = r.json()
    except Exception: data = {'raw': r.text}
    if r.status_code >= 400 or 'error' in data:
        err = data.get('error', {})
        raise RuntimeError(f'Meta API {r.status_code}: {err.get("message", data)}')
    return data

def check_account():
    return api_request('GET', IG_USER_ID, {'fields':'id,username'})

def normalize_hashtags(text):
    parts = text.replace('\n', ' ').split()
    out=[]
    for p in parts:
        p=p.strip()
        if not p: continue
        if not p.startswith('#'): p='#'+p
        if p not in out: out.append(p)
    return ' '.join(out)

def build_caption(job_caption):
    base = (job_caption or '').strip()
    tags = normalize_hashtags(get_setting('hashtags'))
    if base and tags: return base + '\n\n' + tags
    return base or tags

def update_job(job_id, **fields):
    fields['updated_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
    sets=', '.join(f'{k}=?' for k in fields)
    vals=list(fields.values())+[job_id]
    with db() as c: c.execute(f'UPDATE jobs SET {sets} WHERE id=?', vals)

def get_job(job_id):
    with db() as c: return c.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone()

def create_container(job):
    video_url = f'{PUBLIC_BASE}/media/{job["public_key"]}'
    return api_request('POST', f'{IG_USER_ID}/media', {
        'media_type':'REELS', 'video_url':video_url,
        'caption':build_caption(job['caption']),
        'share_to_feed':str(SHARE_TO_FEED).lower()
    })

def wait_container(container_id):
    started=time.time()
    while time.time()-started < POLL_TIMEOUT:
        data=api_request('GET', container_id, {'fields':'status_code,status'})
        code=data.get('status_code')
        if code=='FINISHED': return data
        if code in {'ERROR','EXPIRED'}: raise RuntimeError(data.get('status') or code)
        time.sleep(POLL_INTERVAL)
    raise TimeoutError('Tempo limite aguardando o processamento do Reel.')

def publish(container_id):
    return api_request('POST', f'{IG_USER_ID}/media_publish', {'creation_id':container_id})

def process_job(job_id):
    try:
        update_job(job_id, status='processing', message='Enviando vídeo para a Meta...')
        job=get_job(job_id)
        container=create_container(job)
        cid=container.get('id')
        if not cid: raise RuntimeError(f'Meta não retornou container ID: {container}')
        update_job(job_id, message=f'Container criado: {cid}. Aguardando processamento...')
        wait_container(cid)
        update_job(job_id, message='Vídeo processado. Publicando...')
        result=publish(cid)
        media_id=result.get('id','')
        src=REELS/job['filename']
        if src.exists():
            dst=UPLOADED/src.name
            if dst.exists(): dst=UPLOADED/f'{src.stem}_{int(time.time())}{src.suffix}'
            shutil.move(str(src), str(dst))
        update_job(job_id, status='published', message='Publicado com sucesso.', media_id=media_id)
    except Exception as e:
        update_job(job_id, status='error', message=str(e))

def worker():
    while True:
        try:
            with db() as c:
                # Recover jobs interrupted by a restart.
                c.execute("UPDATE jobs SET status='pending', message='Recolocado na fila após reinício.' WHERE status='processing'")
                row=c.execute("SELECT * FROM jobs WHERE status='pending' ORDER BY id LIMIT 1").fetchone()
            if row:
                process_job(row['id'])
            else:
                time.sleep(3)
        except Exception:
            time.sleep(5)

@app.on_event('startup')
def startup():
    global PUBLIC_BASE
    init_db()
    PUBLIC_BASE = os.getenv('PUBLIC_BASE_URL', '').rstrip('/')
    threading.Thread(target=worker, daemon=True).start()

@app.get('/', response_class=HTMLResponse)
def home(request: Request):
    check_auth(request)
    with db() as c: jobs=c.execute('SELECT * FROM jobs ORDER BY id DESC LIMIT 30').fetchall()
    return templates.TemplateResponse('index.html', {'request':request,'jobs':jobs,'hashtags':get_setting('hashtags'),'username':'@'+(os.getenv('INSTAGRAM_USERNAME','nevesf.concursos')),'public_base':PUBLIC_BASE})

@app.post('/upload')
async def upload(request: Request, video: UploadFile=File(...), caption: str=Form('')):
    check_auth(request)
    if not PUBLIC_BASE: raise HTTPException(500, 'PUBLIC_BASE_URL não configurada.')
    ext=Path(video.filename or '').suffix.lower()
    if ext not in {'.mp4','.mov'}: raise HTTPException(400,'Envie MP4 ou MOV.')
    safe=Path(video.filename or 'video.mp4').name
    unique=f'{uuid.uuid4().hex[:12]}_{safe}'
    dest=REELS/unique
    with dest.open('wb') as f:
        while chunk:=await video.read(1024*1024): f.write(chunk)
    key=uuid.uuid4().hex
    with db() as c:
        c.execute('INSERT INTO jobs(filename,original_name,public_key,caption,status,message) VALUES(?,?,?,?,?,?)',
                  (unique,safe,key,caption.strip(),'pending','Aguardando na fila.'))
    return RedirectResponse('/?key='+quote(request.query_params.get('key','')), status_code=303)

@app.post('/settings')
def settings(request: Request, hashtags: str=Form('')):
    check_auth(request); set_setting('hashtags', hashtags.strip())
    return RedirectResponse('/?key='+quote(request.query_params.get('key','')), status_code=303)

@app.get('/media/{public_key}')
def media(public_key: str):
    with db() as c: row=c.execute('SELECT filename,status FROM jobs WHERE public_key=?',(public_key,)).fetchone()
    if not row or row['status'] in {'published','error'}: raise HTTPException(404,'Vídeo não disponível.')
    path=REELS/row['filename']
    if not path.exists(): raise HTTPException(404,'Arquivo não encontrado.')
    return FileResponse(path, media_type=mimetypes.guess_type(path.name)[0] or 'video/mp4', headers={'Cache-Control':'no-store'})

@app.get('/api/jobs')
def jobs(request: Request):
    check_auth(request)
    with db() as c: rows=c.execute('SELECT * FROM jobs ORDER BY id DESC LIMIT 50').fetchall()
    return JSONResponse([dict(r) for r in rows])

@app.get('/health')
def health(): return {'ok':True,'service':'auto-reels-cloud'}
