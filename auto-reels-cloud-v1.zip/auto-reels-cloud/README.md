# Auto Reels Cloud

Versão em nuvem do Auto Reels. Não depende do computador local. Possui painel web para enviar vídeos, legenda por postagem e hashtags globais aplicadas automaticamente a todas as postagens.

## Variáveis obrigatórias no Railway

- `INSTAGRAM_USER_ID=28617465387918287`
- `INSTAGRAM_ACCESS_TOKEN=SEU_TOKEN` (não coloque no código)
- `INSTAGRAM_USERNAME=nevesf.concursos`
- `PUBLIC_BASE_URL=https://SEU-DOMINIO-RAILWAY`
- `DASHBOARD_KEY=uma_senha_forte`

## Variáveis opcionais

- `INSTAGRAM_API_BASE=https://graph.instagram.com`
- `INSTAGRAM_API_VERSION=v25.0`
- `SHARE_TO_FEED=true`
- `POLL_INTERVAL=10`
- `POLL_TIMEOUT=900`
- `DATA_DIR=/data`

## Railway

1. Crie um projeto e faça deploy deste diretório via GitHub ou Dockerfile.
2. Gere um domínio público no serviço.
3. Configure as variáveis acima.
4. Crie um Volume Railway e monte em `/data`.
5. Preencha `PUBLIC_BASE_URL` com o domínio HTTPS gerado.
6. Abra `https://SEU-DOMINIO/?key=SUA_SENHA`.

O volume mantém a fila e os vídeos entre reinicializações. O token fica em variável secreta, não em arquivo público.

## Funcionamento

- Envie um MP4/MOV.
- Informe uma legenda opcional.
- As hashtags globais são acrescentadas automaticamente.
- O vídeo entra na fila.
- O worker cria o container do Reel, aguarda `FINISHED` e publica.
- Após publicar, o arquivo é movido para `uploaded/`.
